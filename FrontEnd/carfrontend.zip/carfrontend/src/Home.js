import React from 'react'
import Navbar from './common/Navbar'
import { Routes } from 'react-router-dom'
import CarList from './components/Cars/CarList'
import Carousel from './common/Crousel'
import Information from './common/Information'
import Footer from './common/Footer'

const Home = () => {
  return (
    <div>
      <Navbar />
      <Carousel/>
      <Information/>
      <Footer/>
    </div>
  )
}

export default Home
