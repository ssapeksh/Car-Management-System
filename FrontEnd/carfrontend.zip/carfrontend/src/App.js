import React from 'react';
import './App.css';
import Home from './Home';
import { Route, Routes } from 'react-router-dom';

function App() {
  return (
    <div className="App">
      Sample
    </div>
  );
}

export default App;
