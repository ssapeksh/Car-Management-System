import React from 'react';
import { useNavigate } from 'react-router-dom';

const Navbar = () => {
    const navigate = useNavigate();

    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <div className="container-fluid">
                    {/* Logo Section */}
                    <a className="navbar-brand" href="#">
                        <img
                            src="https://www.svgrepo.com/show/446873/fiat-alt.svg" // Adjust the path as necessary
                            alt="Car Logo"
                            style={{ width: '50px', height: 'auto' }} // Adjust size as needed
                        />
                    </a>
                    <button
                        className="navbar-toggler"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent"
                        aria-expanded="false"
                        aria-label="Toggle navigation"
                    >
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                            <li className="nav-item">
                                <a className="nav-link active" aria-current="page" href="#">Home</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" onClick={() => navigate("/carList")}>Cars</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" onClick={() => navigate("/users")}>Users</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" onClick={() => navigate("/orders")}>Orders</a>
                            </li>
                            {/* <li className="nav-item">
                                <a className="nav-link" onClick={() => navigate("/branches")}>Branch</a>
                            </li> */}
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    );
};

export default Navbar;
