import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Spinner from '../../common/Spinner';
import { Button, Table, Dropdown } from 'react-bootstrap';
import PurchaseRentModal from './PurchaseRentModal'; // Import the new modal component
import ConfirmationModal from '../../common/ConfirmationModal'; // Import the modal component
import "./carList.css";

const CarList = () => {
    const [cars, setCars] = useState([]);
    const [loading, setLoading] = useState(false);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [showPurchaseRentModal, setShowPurchaseRentModal] = useState(false);
    const [carToDelete, setCarToDelete] = useState(null);
    const [selectedCar, setSelectedCar] = useState(null);

    const navigate = useNavigate();

    const getAllCars = () => {
        axios.get("http://localhost:5228/api/car")
            .then((res) => {
                setLoading(false);
                setCars(res.data);
            })
            .catch(() => {
                setLoading(false);
                alert("Please try again later");
            });
    };

    useEffect(() => {
        setLoading(true);
        getAllCars();
    }, []);

    const handleDetailsClick = (car) => {
        navigate("/carDetails", {
            state: {
                car: car
            }
        });
    };

    const handleUpdateClick = (car) => {
        navigate("/carForm", {
            state: {
                car: car,
                method: "Update"
            }
        });
    };

    const handleDeleteClick = (car) => {
        setCarToDelete(car);
        setShowDeleteModal(true);
    };

    const handleConfirmDelete = () => {
        axios.delete(`http://localhost:5228/api/Car/${carToDelete.id}`)
            .then(() => {
                setShowDeleteModal(false);
                setCarToDelete(null);
                getAllCars();
            })
            .catch(() => {
                setShowDeleteModal(false);
                alert("Error deleting the car. Please try again later.");
            });
    };

    const handleCancelDelete = () => {
        setShowDeleteModal(false);
        setCarToDelete(null);
    };

    const handlePurchaseRentClick = (car, action) => {
        setSelectedCar({ car, action });
        setShowPurchaseRentModal(true);
    };

    const handlePurchaseRentSubmit = (userId, startDate, endDate) => {
        const { car, action } = selectedCar;
        const apiUrl = action === 'Purchase'
            ? `http://localhost:8007/api/buy?carId=${car.id}&userId=${userId}`
            : `http://localhost:8007/api/rental/rent?carId=${car.id}&userId=${userId}&returnDate=${endDate}`;

        const data = action === 'Rent' ? { startDate } : {};

        axios.post(apiUrl, data)
            .then(() => {
                setShowPurchaseRentModal(false);
                setSelectedCar(null);
                getAllCars();
            })
            .catch(() => {
                setShowPurchaseRentModal(false);
                alert(`Error during ${action.toLowerCase()}. Please try again later.`);
            });
    };

    const handleCancelPurchaseRent = () => {
        setShowPurchaseRentModal(false);
        setSelectedCar(null);
    };

    return (
        <div className="container mt-5">
            <div className='wrapper'>
                <span onClick={() => navigate("/home")}><i className="fa-solid fa-backward"></i></span>
                <h2 className="text-center">Cars List</h2>
                <button type="button" className="btn btn-outline-primary btn-sm" onClick={() => navigate("/carForm", {
                    state: {
                        method: "Create"
                    }
                })}>Add New</button>
            </div>
            {
                loading ? <Spinner /> : (
                    <Table striped bordered hover className="mt-4">
                        <thead className="thead-dark">
                            <tr className='text-center'>
                                <th>Car Name</th>
                                <th>Brand</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {cars.map((car, index) => (
                                <tr key={index} className='text-center'>
                                    <td>{car?.carName}</td>
                                    <td>{car?.brand}</td>
                                    <td>{car?.status}</td>
                                    <td>
                                        <Dropdown className="no-arrow-dropdown">
                                            <Dropdown.Toggle variant="secondary" id="dropdown-basic" className="no-arrow">
                                                <i className="fa-solid fa-ellipsis-vertical"></i>
                                            </Dropdown.Toggle>

                                            <Dropdown.Menu>
                                                <Dropdown.Item onClick={() => handleDetailsClick(car)}>
                                                    Details
                                                </Dropdown.Item>
                                                <Dropdown.Item onClick={() => handleUpdateClick(car)}>
                                                    Update
                                                </Dropdown.Item>
                                                <Dropdown.Item onClick={() => handleDeleteClick(car)}>
                                                    Delete
                                                </Dropdown.Item>
                                                <Dropdown.Item onClick={() => handlePurchaseRentClick(car, 'Purchase')}>
                                                    Purchase
                                                </Dropdown.Item>
                                                <Dropdown.Item onClick={() => handlePurchaseRentClick(car, 'Rent')}>
                                                    Rent
                                                </Dropdown.Item>
                                            </Dropdown.Menu>
                                        </Dropdown>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                )
            }
            <ConfirmationModal
                show={showDeleteModal}
                onClose={handleCancelDelete}
                onConfirm={handleConfirmDelete}
                itemName={carToDelete?.carName}
            />
            <PurchaseRentModal
                show={showPurchaseRentModal}
                onClose={handleCancelPurchaseRent}
                onSubmit={handlePurchaseRentSubmit}
                action={selectedCar?.action}
            />
        </div>
    );
};

export default CarList;
