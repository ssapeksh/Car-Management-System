
import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom';


const CarDeatils = () => {

    const [car, setCar] = useState()

    const location = useLocation()
    const navigate = useNavigate()

    useEffect(() => {
        setCar(location?.state?.car)
    }, [])
    return (
        <div className="container mt-5">
            <div className="row justify-content-center">
                <div className="col-md-8">
                    <div className="card">
                        <div className="card-body">
                            <div style={{ display: "flex", alignItems: "center",justifyContent:"space-between" }} >
                                <span onClick={() => navigate("/carList")} ><i className="fa-solid fa-backward"></i></span>
                                <h4 className="card-title text-center">{car?.carName}</h4>
                                <span onClick={() => navigate("/home")} ><i className="fa-solid fa-house"></i></span>
                            </div>
                            <ul className="list-group list-group-flush">
                                <li className="list-group-item">
                                    <strong>Model:</strong> {car?.carModel}
                                </li>
                                <li className="list-group-item">
                                    <strong>Brand:</strong> {car?.brand}
                                </li>
                                <li className="list-group-item">
                                    <strong>Price:</strong> ${car?.price}
                                </li>
                                <li className="list-group-item">
                                    <strong>Available:</strong> {car?.available ? "Yes" : "No"}
                                </li>
                                <li className="list-group-item">
                                    <strong>Status:</strong> {car?.status}
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default CarDeatils
