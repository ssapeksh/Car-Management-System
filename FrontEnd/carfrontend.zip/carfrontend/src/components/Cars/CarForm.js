import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Button, Form, Container, Row, Col, Spinner } from 'react-bootstrap';
import { useNavigate, useLocation } from 'react-router-dom';

const CarForm = () => {
    const [carDetails, setCarDetails] = useState({
        carName: '',
        carModel: '',
        brand: '',
        price: '',
        available: false,
        status: 'Available'
    });
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();
    const location = useLocation();

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setCarDetails({
            ...carDetails,
            [name]: type === 'checkbox' ? checked : value
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        setLoading(true);

        if (location?.state?.method === 'Create') {
            axios.post('http://localhost:5228/api/car', carDetails)
                .then(() => {
                    setLoading(false);
                    navigate('/carList'); // Navigate to the car list after successful submission
                })
                .catch(() => {
                    setLoading(false);
                    alert('Error adding the car. Please try again later.');
                });
        } else if (location?.state?.method === 'Update') {
            const carId = location?.state?.car?.id;
            axios.put(`http://localhost:5228/api/car/${carId}`, carDetails)
                .then(() => {
                    setLoading(false);
                    navigate('/carList'); // Navigate to the car list after successful update
                })
                .catch(() => {
                    setLoading(false);
                    alert('Error updating the car. Please try again later.');
                });
        }
    };

    const handleCancel = () => {
        navigate('/carList'); // Navigate to the car list or another relevant page
    };

    useEffect(() => {
        if (location?.state?.car) {
            setCarDetails(location.state.car);
        }
    }, [location.state.car]);

    return (
        <Container>
            <h1 className="my-4 text-center">Car Details Form</h1>
            <Form onSubmit={handleSubmit}>
                <Row className="mb-3">
                    <Form.Group as={Col} controlId="formCarName">
                        <Form.Label>Car Name</Form.Label>
                        <Form.Control
                            type="text"
                            name="carName"
                            value={carDetails.carName}
                            onChange={handleChange}
                            placeholder="Enter car name"
                            required
                        />
                    </Form.Group>

                    <Form.Group as={Col} controlId="formCarModel">
                        <Form.Label>Car Model</Form.Label>
                        <Form.Control
                            type="text"
                            name="carModel"
                            value={carDetails.carModel}
                            onChange={handleChange}
                            placeholder="Enter car model"
                            required
                        />
                    </Form.Group>
                </Row>

                <Row className="mb-3">
                    <Form.Group as={Col} controlId="formBrand">
                        <Form.Label>Brand</Form.Label>
                        <Form.Control
                            type="text"
                            name="brand"
                            value={carDetails.brand}
                            onChange={handleChange}
                            placeholder="Enter brand"
                            required
                        />
                    </Form.Group>

                    <Form.Group as={Col} controlId="formPrice">
                        <Form.Label>Price</Form.Label>
                        <Form.Control
                            type="number"
                            name="price"
                            value={carDetails.price}
                            onChange={handleChange}
                            placeholder="Enter price"
                            required
                        />
                    </Form.Group>
                </Row>

                <Row className="mb-3">
                    <Form.Group as={Col} controlId="formAvailable">
                        <Form.Check
                            type="checkbox"
                            name="available"
                            checked={carDetails.available}
                            onChange={handleChange}
                            label="Available"
                        />
                    </Form.Group>

                    <Form.Group as={Col} controlId="formStatus">
                        <Form.Label>Status</Form.Label>
                        <Form.Select
                            name="status"
                            value={carDetails.status}
                            onChange={handleChange}
                        >
                            <option value="Available">Available</option>
                            <option value="Sold">Sold</option>
                            <option value="Pending">Pending</option>
                        </Form.Select>
                    </Form.Group>
                </Row>

                {loading ? (
                    <Spinner animation="border" />
                ) : (
                    <Button variant="primary" type="submit" className="me-2">
                        {location?.state?.method === 'Create' ? 'Add Car' : 'Update Car'}
                    </Button>
                )}
                <Button variant="secondary" onClick={handleCancel}>
                    Cancel
                </Button>
            </Form>
        </Container>
    );
};

export default CarForm;
