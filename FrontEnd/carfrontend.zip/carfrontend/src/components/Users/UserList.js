import React, { useEffect, useState } from 'react';
import './UserList.css'; // Create a CSS file for custom styles
import axios from 'axios';
import Spinner from '../../common/Spinner';
import { Button, Table, Modal, Dropdown } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

const UserList = () => {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(false);
    const [showConfirm, setShowConfirm] = useState(false);
    const [selectedUserId, setSelectedUserId] = useState(null);
    const navigate = useNavigate();

    const getUsers = () => {
        axios.get("http://localhost:5228/api/user")
            .then((res) => {
                setLoading(false);
                setUsers(res.data);
            })
            .catch((err) => {
                setLoading(false);
                alert("Please try again later");
            });
    };

    useEffect(() => {
        setLoading(true);
        getUsers();
    }, []);

    const handleDelete = (userId) => {
        setSelectedUserId(userId);
        setShowConfirm(true);
    };

    const confirmDelete = () => {
        setLoading(true);
        axios.delete(`http://localhost:5228/api/user/${selectedUserId}`)
            .then(() => {
                setLoading(false);
                setShowConfirm(false);
                setUsers(users.filter(user => user.id !== selectedUserId));
            })
            .catch(() => {
                setLoading(false);
                alert('Error deleting user. Please try again later.');
            });
    };

    const handleCancel = () => {
        setShowConfirm(false);
    };

    const handleDetailsClick = (user) => {
        navigate("/userDetails", {
            state: {
                user: user
            }
        });
    };

    return (
        <div className="user-list-container">
            <div className='wrapper'>
                <span onClick={() => navigate("/home")}><i className="fa-solid fa-backward"></i></span>
                <h2 className="text-center">Users List</h2>
                <button type="button" className="btn btn-outline-primary btn-sm" onClick={() => navigate("/userForm", {
                    state: {
                        method: "Create"
                    }
                })}>Add New</button>
            </div>
            {
                loading ? <Spinner /> : (
                    <Table className="user-table" striped bordered hover>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Age</th>
                                <th>Email</th>
                                <th>Status</th>
                                <th>City</th>
                                <th>Role</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {users.map((user) => (
                                <tr key={user.id}>
                                    <td>{user.user_Name}</td>
                                    <td>{user.user_Age}</td>
                                    <td>{user.email}</td>
                                    <td>{user.status}</td>
                                    <td>{user.city}</td>
                                    <td>{user.role}</td>
                                    <td>
                                        <Dropdown>
                                            <Dropdown.Toggle variant="secondary" id="dropdown-basic">
                                                <i className="fa-solid fa-ellipsis-vertical"></i>
                                            </Dropdown.Toggle>

                                            <Dropdown.Menu>
                                                <Dropdown.Item onClick={() => navigate("/userForm", {
                                                    state: {
                                                        user: user,
                                                        method: "Update"
                                                    }
                                                })}>
                                                    Update
                                                </Dropdown.Item>
                                                <Dropdown.Item onClick={() => handleDelete(user.id)}>
                                                    Delete
                                                </Dropdown.Item>
                                            </Dropdown.Menu>
                                        </Dropdown>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                )
            }

            <Modal show={showConfirm} onHide={handleCancel}>
                <Modal.Header closeButton>
                    <Modal.Title>Confirm Delete</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    Are you sure you want to delete this user?
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleCancel}>
                        Cancel
                    </Button>
                    <Button variant="danger" onClick={confirmDelete}>
                        Delete
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
};

export default UserList;
