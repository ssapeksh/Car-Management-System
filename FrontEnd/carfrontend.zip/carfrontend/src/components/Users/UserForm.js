import React, { useState } from 'react';
import { Button, Form, Container, Row, Col, Spinner } from 'react-bootstrap';
import axios from 'axios';
import { useLocation, useNavigate } from 'react-router-dom';

const UserForm = ({ method, user }) => {
    const [formData, setFormData] = useState({
        user_Name: '',
        user_Age: '',
        email: '',
        password: '',
        status: 'Active',
        city: '',
        role: 'User'
    });

    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();
    const location = useLocation()

    // Initialize form data if editing an existing user
    React.useEffect(() => {
        if (location?.state?.method === 'Update' && location?.state?.user) {
            setFormData(location?.state?.user);
        }
    }, [method, user]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        setLoading(true);

        const url = location?.state?.method === 'Create'
            ? 'http://localhost:5228/api/user'
            : `http://localhost:5228/api/user/${location?.state?.user.id}`;

        const request = location?.state?.method === 'Create'
            ? axios.post(url, formData)
            : axios.put(url, formData);

        request
            .then(() => {
                setLoading(false);
                navigate('/users'); 
            })
            .catch(() => {
                setLoading(false);
                alert(`Error ${method === 'Create' ? 'adding' : 'updating'} the user. Please try again later.`);
            });
    };

    const handleCancel = () => {
        navigate('/users');
    };

    return (
        <Container>
            <h1 className="my-4 text-center">{location?.state?.method === 'Create' ? 'Add New User' : 'Edit User'}</h1>
            <Form onSubmit={handleSubmit}>
                <Row className="mb-3">
                    <Form.Group as={Col} controlId="formUserName">
                        <Form.Label>Full Name</Form.Label>
                        <Form.Control
                            type="text"
                            name="user_Name"
                            value={formData.user_Name}
                            onChange={handleChange}
                            placeholder="Enter full name"
                            required
                        />
                    </Form.Group>

                    <Form.Group as={Col} controlId="formUserAge">
                        <Form.Label>Age</Form.Label>
                        <Form.Control
                            type="number"
                            name="user_Age"
                            value={formData.user_Age}
                            onChange={handleChange}
                            placeholder="Enter age"
                            required
                        />
                    </Form.Group>
                </Row>

                <Row className="mb-3">
                    <Form.Group as={Col} controlId="formEmail">
                        <Form.Label>Email</Form.Label>
                        <Form.Control
                            type="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            placeholder="Enter email"
                            required
                        />
                    </Form.Group>

                    <Form.Group as={Col} controlId="formPassword">
                        <Form.Label>Password</Form.Label>
                        <Form.Control
                            type="password"
                            name="password"
                            value={formData.password}
                            onChange={handleChange}
                            placeholder="Enter password"
                            required
                        />
                    </Form.Group>
                </Row>

                <Row className="mb-3">
                    <Form.Group as={Col} controlId="formStatus">
                        <Form.Label>Status</Form.Label>
                        <Form.Select
                            name="status"
                            value={formData.status}
                            onChange={handleChange}
                        >
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </Form.Select>
                    </Form.Group>

                    <Form.Group as={Col} controlId="formCity">
                        <Form.Label>City</Form.Label>
                        <Form.Control
                            type="text"
                            name="city"
                            value={formData.city}
                            onChange={handleChange}
                            placeholder="Enter city"
                        />
                    </Form.Group>
                </Row>

                <Row className="mb-3">
                    <Form.Group as={Col} controlId="formRole">
                        <Form.Label>Role</Form.Label>
                        <Form.Select
                            name="role"
                            value={formData.role}
                            onChange={handleChange}
                        >
                            <option value="User">User</option>
                            <option value="Admin">Admin</option>
                        </Form.Select>
                    </Form.Group>
                </Row>

                {loading ? (
                    <Spinner animation="border" />
                ) : (
                    <Button variant="primary" type="submit" className="me-2">
                        {location?.state?.method === 'Create' ? 'Add User' : 'Update User'}
                    </Button>
                )}
                <Button variant="secondary" onClick={handleCancel}>
                    Cancel
                </Button>
            </Form>
        </Container>
    );
};

export default UserForm;
