import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Spinner from '../../common/Spinner';
import { Button, Container, Tab, Tabs, Table } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

const PurchaseOrderList = () => {
    const [purchaseOrders, setPurchaseOrders] = useState([]);
    const [rentalOrders, setRentalOrders] = useState([]);
    const [loading, setLoading] = useState(false);
    const [activeTab, setActiveTab] = useState('purchase');
    const navigate = useNavigate();

    // Fetch Purchase Orders
    const getPurchaseOrders = () => {
        setLoading(true);
        axios.get('http://localhost:8007/api/GetListOfPurchases')
            .then((res) => {
                setLoading(false);
                setPurchaseOrders(res.data);
            })
            .catch((err) => {
                setLoading(false);
                alert('Error fetching purchase orders. Please try again later.');
            });
    };

    // Fetch Rental Orders
    const getRentalOrders = () => {
        setLoading(true);
        axios.get('http://localhost:8007/api/rental/GetAllRentalRecords') // Adjust endpoint as needed
            .then((res) => {
                setLoading(false);
                setRentalOrders(res.data);
            })
            .catch((err) => {
                setLoading(false);
                alert('Error fetching rental orders. Please try again later.');
            });
    };

    useEffect(() => {
        if (activeTab === 'purchase') {
            getPurchaseOrders();
        } else if (activeTab === 'rental') {
            getRentalOrders();
        }
    }, [activeTab]);

    return (
        <Container>
            <div className="my-4">
                <h2 className="text-center">Order History</h2>
                <Button
                    variant="outline-primary"
                    onClick={() => navigate("/home")}
                >
                    Back to Home
                </Button>
            </div>

            <Tabs
                id="order-history-tabs"
                activeKey={activeTab}
                onSelect={(key) => setActiveTab(key)}
                className="mb-3"
            >
                <Tab eventKey="purchase" title="Purchase History">
                    {loading ? (
                        <Spinner />
                    ) : (
                        <Table striped bordered hover className="mt-4">
                            <thead>
                                <tr>
                                    <th>Car Status</th>
                                    <th>Car Brand</th>
                                    <th>User City</th>
                                    <th>Username</th>
                                    <th>Purchase Date</th>
                                    <th>Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                {purchaseOrders.map((order) => (
                                    <tr key={order.id}>
                                        <td>{order.car.status}</td>
                                        <td>{order.car.brand}</td>
                                        <td>{order.user.city}</td>
                                        <td>{order.user.username}</td>
                                        <td>{new Date(order.purchaseDate).toLocaleDateString()}</td>
                                        <td>${order.price?.toFixed(2)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </Table>
                    )}
                </Tab>
                <Tab eventKey="rental" title="Rental History">
                    {loading ? (
                        <Spinner />
                    ) : (
                        <Table striped bordered hover className="mt-4">
                            <thead>
                                <tr>
                                    <th>Car Status</th>
                                    <th>Car Brand</th>
                                    <th>User City</th>
                                    <th>Username</th>
                                    <th>Rental Date</th>
                                    <th>Return Date</th>
                                    <th>Total Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                {rentalOrders.map((order) => (
                                    <tr key={order.id}>
                                        <td>{order.car.status}</td>
                                        <td>{order.car.brand}</td>
                                        <td>{order.user.city}</td>
                                        <td>{order.user.username}</td>
                                        <td>{new Date(order.rentalDate).toLocaleDateString()}</td>
                                        <td>{new Date(order.returnDate).toLocaleDateString()}</td>
                                        <td>${order.totalPrice?.toFixed(2)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </Table>
                    )}
                </Tab>
            </Tabs>
        </Container>
    );
};

export default PurchaseOrderList;
