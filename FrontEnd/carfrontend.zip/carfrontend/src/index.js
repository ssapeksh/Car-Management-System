import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
import './index.css';
import App from './App';
import Home from './Home';
import Navbar from './common/Navbar';
import Login from './common/Login';
import Register from './common/Register';
import CarDeatils from './components/Cars/CarDeatils';
import CarList from './components/Cars/CarList';
import UserList from './components/Users/UserList';
import CarForm from './components/Cars/CarForm';
import UserForm from './components/Users/UserForm';
import PurchaseOrderList from './components/Orders/OrderList';
import BranchList from './components/Branch/BranchList';
import BranchForm from './components/Branch/BranchForm';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Router>

      <Routes>
        <Route path='/' element={<Login />} />
        <Route path='/home' element={<Home />} />
        <Route path='/userForm' element={<UserForm />} />
        <Route path='/users' element={<UserList />} />
        <Route path='/carDetails' element={<CarDeatils />} />
        <Route path='/carList' element={<CarList />} />
        <Route path='/orders' element={<PurchaseOrderList />} />
        <Route path='/carForm' element={<CarForm />} />
        <Route path='/register' element={<Register />} />
        <Route path='/branches' element={<BranchList />} />
        <Route path='/branchForm' element={<BranchForm />} />
      </Routes>
    </Router>
  </React.StrictMode>
);